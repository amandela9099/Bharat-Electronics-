
  # Bharat Electronics Sales App

  This is a code bundle for Bharat Electronics Sales App. The original project is available at https://www.figma.com/design/DYQ4SwApRSO0Ek34lPLjCL/Bharat-Electronics-Sales-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  