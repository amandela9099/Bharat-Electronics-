import { Home, Layers, Heart, ShoppingCart, User } from 'lucide-react';

interface BottomNavProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  cartCount?: number;
  wishlistCount?: number;
}

export function BottomNav({ currentPage, onNavigate, cartCount = 0, wishlistCount = 0 }: BottomNavProps) {
  const navItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'category', icon: Layers, label: 'Category' },
    { id: 'wishlist', icon: Heart, label: 'Wishlist', count: wishlistCount },
    { id: 'cart', icon: ShoppingCart, label: 'Cart', count: cartCount },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-lg md:hidden">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="relative flex flex-col items-center justify-center p-2 min-w-[60px] transition-all"
            >
              <div className="relative">
                <Icon
                  className={`w-6 h-6 transition-colors ${
                    isActive ? 'text-cyan-500' : 'text-gray-600'
                  }`}
                />
                {item.count && item.count > 0 && (
                  <span className="absolute -top-2 -right-2 bg-cyan-400 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {item.count}
                  </span>
                )}
              </div>
              <span
                className={`text-xs mt-1 transition-colors ${
                  isActive ? 'text-cyan-500 font-medium' : 'text-gray-600'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
