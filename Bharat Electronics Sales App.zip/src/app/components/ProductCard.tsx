import { Heart, Eye } from 'lucide-react';
import { useState } from 'react';

export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  rating?: number;
  inStock?: boolean;
}

interface ProductCardProps {
  product: Product;
  onWishlistToggle?: (productId: string) => void;
  isInWishlist?: boolean;
}

export function ProductCard({ product, onWishlistToggle, isInWishlist = false }: ProductCardProps) {
  const [imageError, setImageError] = useState(false);

  return (
    <div className="group bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100">
      {/* Image Container */}
      <div className="relative aspect-square bg-gray-100 overflow-hidden">
        <img
          src={imageError ? 'https://via.placeholder.com/300?text=' + product.name : product.image}
          alt={product.name}
          onError={() => setImageError(true)}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
        />
        
        {/* Wishlist Button */}
        <button
          onClick={() => onWishlistToggle?.(product.id)}
          className="absolute top-3 right-3 p-2 bg-white/90 backdrop-blur-sm rounded-full shadow-md hover:bg-white transition-all"
        >
          <Heart
            className={`w-5 h-5 transition-colors ${
              isInWishlist ? 'fill-red-500 text-red-500' : 'text-gray-600'
            }`}
          />
        </button>

        {/* View Button - appears on hover */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <button className="px-4 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition-colors flex items-center gap-2">
            <Eye className="w-4 h-4" />
            <span>Quick View</span>
          </button>
        </div>

        {/* Stock Badge */}
        {product.inStock === false && (
          <div className="absolute top-3 left-3 px-2 py-1 bg-red-500 text-white text-xs font-medium rounded">
            Out of Stock
          </div>
        )}
      </div>

      {/* Product Info */}
      <div className="p-4">
        <p className="text-xs text-cyan-600 font-medium mb-1">{product.category}</p>
        <h3 className="font-medium text-gray-800 mb-2 line-clamp-2 min-h-[2.5rem]">
          {product.name}
        </h3>
        
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <p className="text-xl font-bold text-[#0a1628]">
              ₹{product.price.toLocaleString()}
            </p>
            {product.rating && (
              <div className="flex items-center gap-1 mt-1">
                <div className="flex text-yellow-400">
                  {'★'.repeat(Math.floor(product.rating))}
                  {'☆'.repeat(5 - Math.floor(product.rating))}
                </div>
                <span className="text-xs text-gray-500">({product.rating})</span>
              </div>
            )}
          </div>
          
          <button className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white text-sm font-medium rounded-lg hover:from-cyan-600 hover:to-blue-600 transition-all shadow-md">
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}
