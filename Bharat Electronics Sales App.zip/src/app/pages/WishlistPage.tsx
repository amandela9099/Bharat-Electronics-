import { Heart, Trash2, ShoppingCart, ArrowLeftRight } from 'lucide-react';
import { products } from '../data/products';

interface WishlistPageProps {
  wishlist: string[];
  onWishlistToggle: (productId: string) => void;
  onAddToCart: (productId: string) => void;
}

export function WishlistPage({ wishlist, onWishlistToggle, onAddToCart }: WishlistPageProps) {
  const wishlistProducts = products.filter(p => wishlist.includes(p.id));

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <Heart className="w-8 h-8 text-red-500 fill-red-500" />
            <h1 className="text-2xl md:text-3xl font-bold text-[#0a1628]">My Wishlist</h1>
          </div>
          <p className="text-gray-600 mt-2">{wishlistProducts.length} items saved</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        {wishlistProducts.length === 0 ? (
          <div className="text-center py-16">
            <Heart className="w-20 h-20 text-gray-300 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-700 mb-2">Your wishlist is empty</h2>
            <p className="text-gray-500 mb-6">Save items you like to view them later</p>
            <button className="px-6 py-3 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition-colors">
              Explore Products
            </button>
          </div>
        ) : (
          <>
            {/* Compare Button */}
            {wishlistProducts.length >= 2 && (
              <div className="mb-6 flex justify-end">
                <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:border-cyan-500 hover:text-cyan-600 transition-all">
                  <ArrowLeftRight className="w-4 h-4" />
                  <span>Compare ({wishlistProducts.length})</span>
                </button>
              </div>
            )}

            {/* Wishlist Items */}
            <div className="space-y-4">
              {wishlistProducts.map((product) => (
                <div
                  key={product.id}
                  className="group bg-white rounded-xl shadow-md hover:shadow-lg transition-all overflow-hidden border border-gray-100"
                >
                  <div className="flex flex-col md:flex-row">
                    {/* Image */}
                    <div className="w-full md:w-48 aspect-square md:aspect-auto bg-gray-100">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>

                    {/* Content */}
                    <div className="flex-1 p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                        <div className="flex-1">
                          <p className="text-xs text-cyan-600 font-medium mb-1">{product.category}</p>
                          <h3 className="text-lg font-semibold text-[#0a1628] mb-2">{product.name}</h3>
                          
                          {product.rating && (
                            <div className="flex items-center gap-1 mb-3">
                              <div className="flex text-yellow-400 text-sm">
                                {'★'.repeat(Math.floor(product.rating))}
                                {'☆'.repeat(5 - Math.floor(product.rating))}
                              </div>
                              <span className="text-sm text-gray-500">({product.rating})</span>
                            </div>
                          )}

                          <div className="flex items-baseline gap-3 mb-4">
                            <p className="text-2xl font-bold text-[#0a1628]">
                              ₹{product.price.toLocaleString()}
                            </p>
                            {product.inStock !== false ? (
                              <span className="text-sm text-green-600 font-medium">In Stock</span>
                            ) : (
                              <span className="text-sm text-red-600 font-medium">Out of Stock</span>
                            )}
                          </div>

                          {/* Quick View Details */}
                          <div className="text-sm text-gray-600 space-y-1">
                            <p>• Free Delivery Available</p>
                            <p>• 1 Year Warranty</p>
                            <p>• Easy Returns within 7 days</p>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex md:flex-col gap-2">
                          <button
                            onClick={() => onAddToCart(product.id)}
                            disabled={product.inStock === false}
                            className="flex-1 md:flex-initial flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg hover:from-cyan-600 hover:to-blue-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
                          >
                            <ShoppingCart className="w-4 h-4" />
                            <span>Add to Cart</span>
                          </button>
                          
                          <button
                            onClick={() => onWishlistToggle(product.id)}
                            className="flex-1 md:flex-initial flex items-center justify-center gap-2 px-4 py-2 border border-red-300 text-red-600 rounded-lg hover:bg-red-50 transition-all"
                          >
                            <Trash2 className="w-4 h-4" />
                            <span>Remove</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* View at Home Button */}
            <div className="mt-8 p-6 bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl border border-cyan-200">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="text-lg font-bold text-[#0a1628] mb-1">
                    Try View at Home
                  </h3>
                  <p className="text-gray-600 text-sm">
                    See how these products would look in your space using AR
                  </p>
                </div>
                <button className="px-6 py-3 bg-cyan-500 text-white font-medium rounded-lg hover:bg-cyan-600 transition-colors shadow-md whitespace-nowrap">
                  Preview in AR
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
