import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Zap } from 'lucide-react';
import { ProductCard } from '../components/ProductCard';
import { products, categories } from '../data/products';

interface HomePageProps {
  onWishlistToggle: (productId: string) => void;
  wishlist: string[];
}

const banners = [
  {
    id: 1,
    title: 'Advanced Electronics for Smart Living',
    subtitle: 'Experience innovation at your fingertips',
    image: 'https://images.unsplash.com/photo-1571857089849-f6390447191a?w=1200',
    color: 'from-blue-900 to-cyan-600'
  },
  {
    id: 2,
    title: 'Modern Appliances for Modern Homes',
    subtitle: 'Upgrade your lifestyle with cutting-edge technology',
    image: 'https://images.unsplash.com/photo-1642979427252-13d5fd18bb61?w=1200',
    color: 'from-purple-900 to-blue-600'
  },
  {
    id: 3,
    title: 'Smart Home Technology',
    subtitle: 'Connected living made simple',
    image: 'https://images.unsplash.com/photo-1650682009477-52fd77302b78?w=1200',
    color: 'from-cyan-900 to-teal-600'
  }
];

export function HomePage({ onWishlistToggle, wishlist }: HomePageProps) {
  const [currentBanner, setCurrentBanner] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Auto-slide banner
  useEffect(() => {
    if (isPaused) return;
    
    const interval = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isPaused]);

  const nextBanner = () => {
    setCurrentBanner((prev) => (prev + 1) % banners.length);
  };

  const prevBanner = () => {
    setCurrentBanner((prev) => (prev - 1 + banners.length) % banners.length);
  };

  const featuredProducts = products.slice(0, 8);

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      {/* Hero Banner Carousel */}
      <div 
        className="relative h-[400px] md:h-[500px] overflow-hidden"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        {banners.map((banner, index) => (
          <div
            key={banner.id}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentBanner ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <div className="absolute inset-0">
              <img
                src={banner.image}
                alt={banner.title}
                className="w-full h-full object-cover"
              />
              <div className={`absolute inset-0 bg-gradient-to-r ${banner.color} opacity-80`}></div>
            </div>
            
            <div className="relative h-full flex items-center justify-center text-center px-4">
              <div className="max-w-4xl space-y-4 animate-fade-in">
                <h2 className="text-4xl md:text-6xl font-bold text-white drop-shadow-lg">
                  {banner.title}
                </h2>
                <p className="text-xl md:text-2xl text-white/90 drop-shadow">
                  {banner.subtitle}
                </p>
                <button className="mt-6 px-8 py-3 bg-cyan-400 text-[#0a1628] font-bold rounded-lg hover:bg-cyan-300 transition-all shadow-xl hover:shadow-2xl transform hover:scale-105">
                  Shop Now
                </button>
              </div>
            </div>
          </div>
        ))}

        {/* Navigation Arrows */}
        <button
          onClick={prevBanner}
          className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-all"
        >
          <ChevronLeft className="w-6 h-6 text-white" />
        </button>
        <button
          onClick={nextBanner}
          className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-all"
        >
          <ChevronRight className="w-6 h-6 text-white" />
        </button>

        {/* Dots Indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
          {banners.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentBanner(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentBanner ? 'w-8 bg-cyan-400' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Category Shortcuts */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold text-[#0a1628] mb-6">Shop by Category</h2>
        <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-12 gap-4">
          {categories.map((category) => (
            <button
              key={category.id}
              className="flex flex-col items-center justify-center p-4 bg-white rounded-xl shadow-md hover:shadow-xl transition-all hover:scale-105 group border border-gray-100"
            >
              <div className="text-4xl mb-2 group-hover:scale-110 transition-transform">
                {category.icon}
              </div>
              <span className="text-xs text-gray-700 font-medium text-center">
                {category.name}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Featured Products */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Zap className="w-6 h-6 text-cyan-500" />
            <h2 className="text-2xl font-bold text-[#0a1628]">Featured Products</h2>
          </div>
          <button className="text-cyan-600 hover:text-cyan-700 font-medium text-sm md:text-base">
            View All →
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onWishlistToggle={onWishlistToggle}
              isInWishlist={wishlist.includes(product.id)}
            />
          ))}
        </div>
      </div>

      {/* View at Home Section */}
      <div className="max-w-7xl mx-auto px-4 py-8 mb-8">
        <div className="relative rounded-2xl overflow-hidden shadow-2xl">
          <img
            src="https://images.unsplash.com/photo-1556912172-45b7abe8b7e1?w=1200"
            alt="View at Home"
            className="w-full h-[300px] md:h-[400px] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a1628]/90 to-transparent flex items-center">
            <div className="px-8 md:px-16 max-w-2xl">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Visualize Before You Buy
              </h2>
              <p className="text-white/90 text-lg mb-6">
                See how our products look in your home with AR technology
              </p>
              <button className="px-8 py-3 bg-cyan-400 text-[#0a1628] font-bold rounded-lg hover:bg-cyan-300 transition-all shadow-xl">
                Try View at Home
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
