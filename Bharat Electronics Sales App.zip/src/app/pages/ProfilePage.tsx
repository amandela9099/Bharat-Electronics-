import { User, MapPin, Package, Heart, HeadphonesIcon, LogOut, ChevronRight } from 'lucide-react';

export function ProfilePage() {
  const menuItems = [
    { id: 'orders', icon: Package, label: 'My Orders', description: 'Track, return or buy again' },
    { id: 'addresses', icon: MapPin, label: 'Addresses', description: 'Manage delivery addresses' },
    { id: 'wishlist', icon: Heart, label: 'Wishlist', description: 'Your saved items' },
    { id: 'support', icon: HeadphonesIcon, label: 'Support', description: 'Get help with your orders' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-[#0a1628] to-cyan-900 text-white">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
              <User className="w-10 h-10" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Rajesh Kumar</h1>
              <p className="text-cyan-200">rajesh.kumar@email.com</p>
              <p className="text-sm text-cyan-300 mt-1">+91 98765 43210</p>
            </div>
          </div>
        </div>
      </div>

      {/* Menu Cards */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid md:grid-cols-2 gap-4 mb-6">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-md hover:shadow-lg transition-all border border-gray-100 text-left group"
              >
                <div className="p-3 bg-cyan-50 rounded-lg group-hover:bg-cyan-100 transition-colors">
                  <Icon className="w-6 h-6 text-cyan-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-[#0a1628] mb-1">{item.label}</h3>
                  <p className="text-sm text-gray-600">{item.description}</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-cyan-600 transition-colors" />
              </button>
            );
          })}
        </div>

        {/* Recent Orders */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-6 border border-gray-100">
          <h2 className="font-bold text-lg text-[#0a1628] mb-4">Recent Orders</h2>
          <div className="space-y-4">
            {[1, 2].map((order) => (
              <div key={order} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-16 h-16 bg-gray-200 rounded-lg"></div>
                <div className="flex-1">
                  <h3 className="font-medium text-[#0a1628]">Order #BEE{order}234567</h3>
                  <p className="text-sm text-gray-600">Delivered on {order === 1 ? 'Dec 25' : 'Dec 15'}, 2025</p>
                </div>
                <button className="text-sm text-cyan-600 hover:text-cyan-700 font-medium">
                  View Details
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Account Settings */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-6 border border-gray-100">
          <h2 className="font-bold text-lg text-[#0a1628] mb-4">Account Settings</h2>
          <div className="space-y-3">
            <button className="w-full flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors text-left">
              <span className="text-gray-700">Edit Profile</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors text-left">
              <span className="text-gray-700">Notifications</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors text-left">
              <span className="text-gray-700">Privacy & Security</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>

        {/* Logout Button */}
        <button className="w-full flex items-center justify-center gap-2 p-4 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-colors font-medium">
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>

        {/* App Info */}
        <div className="mt-6 text-center text-sm text-gray-500 space-y-1">
          <p>Version 1.0.0</p>
          <div className="flex items-center justify-center gap-4">
            <button className="hover:text-cyan-600">Privacy Policy</button>
            <span>•</span>
            <button className="hover:text-cyan-600">Terms of Service</button>
          </div>
        </div>
      </div>
    </div>
  );
}
