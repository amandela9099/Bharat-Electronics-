import { useState } from 'react';
import { Grid, List, SlidersHorizontal, ChevronDown } from 'lucide-react';
import { ProductCard } from '../components/ProductCard';
import { products } from '../data/products';

interface CategoryPageProps {
  onWishlistToggle: (productId: string) => void;
  wishlist: string[];
}

type ViewMode = 'grid' | 'list';
type SortOption = 'name' | 'price-low' | 'price-high' | 'rating';

const priceRanges = [
  { label: 'Under ₹1,000', min: 0, max: 1000 },
  { label: '₹1,000 - ₹5,000', min: 1000, max: 5000 },
  { label: '₹5,000 - ₹10,000', min: 5000, max: 10000 },
  { label: '₹10,000 - ₹25,000', min: 10000, max: 25000 },
  { label: 'Above ₹25,000', min: 25000, max: Infinity },
];

const usageTypes = ['Home', 'Industrial', 'Commercial'];
const powerRatings = ['Low Power', 'Medium Power', 'High Power'];

export function CategoryPage({ onWishlistToggle, wishlist }: CategoryPageProps) {
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriceRange, setSelectedPriceRange] = useState<number | null>(null);
  const [selectedUsage, setSelectedUsage] = useState<string[]>([]);
  const [selectedPower, setSelectedPower] = useState<string[]>([]);
  const [inStockOnly, setInStockOnly] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>('name');

  // Get unique categories
  const categories = ['all', ...Array.from(new Set(products.map(p => p.category)))];

  // Filter products
  let filteredProducts = products;

  if (selectedCategory !== 'all') {
    filteredProducts = filteredProducts.filter(p => p.category === selectedCategory);
  }

  if (selectedPriceRange !== null) {
    const range = priceRanges[selectedPriceRange];
    filteredProducts = filteredProducts.filter(p => p.price >= range.min && p.price <= range.max);
  }

  if (inStockOnly) {
    filteredProducts = filteredProducts.filter(p => p.inStock !== false);
  }

  // Sort products
  filteredProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'rating':
        return (b.rating || 0) - (a.rating || 0);
      default:
        return a.name.localeCompare(b.name);
    }
  });

  const toggleUsage = (usage: string) => {
    setSelectedUsage(prev =>
      prev.includes(usage) ? prev.filter(u => u !== usage) : [...prev, usage]
    );
  };

  const togglePower = (power: string) => {
    setSelectedPower(prev =>
      prev.includes(power) ? prev.filter(p => p !== power) : [...prev, power]
    );
  };

  const clearFilters = () => {
    setSelectedCategory('all');
    setSelectedPriceRange(null);
    setSelectedUsage([]);
    setSelectedPower([]);
    setInStockOnly(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-[73px] md:top-[57px] z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            <h1 className="text-xl md:text-2xl font-bold text-[#0a1628]">All Products</h1>
            
            <div className="flex items-center gap-2">
              {/* Sort Dropdown */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400"
              >
                <option value="name">Name</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Rating</option>
              </select>

              {/* View Toggle */}
              <div className="hidden md:flex border border-gray-300 rounded-lg">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 ${viewMode === 'grid' ? 'bg-cyan-500 text-white' : 'text-gray-600'} rounded-l-lg transition-colors`}
                >
                  <Grid className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 ${viewMode === 'list' ? 'bg-cyan-500 text-white' : 'text-gray-600'} rounded-r-lg transition-colors`}
                >
                  <List className="w-5 h-5" />
                </button>
              </div>

              {/* Filter Button */}
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2 px-4 py-2 bg-[#0a1628] text-white rounded-lg hover:bg-[#0a1628]/90 transition-colors"
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span className="hidden md:inline">Filters</span>
              </button>
            </div>
          </div>

          {/* Active Filters Chips */}
          {(selectedCategory !== 'all' || selectedPriceRange !== null || inStockOnly) && (
            <div className="flex flex-wrap items-center gap-2 mt-4">
              <span className="text-sm text-gray-600">Active filters:</span>
              {selectedCategory !== 'all' && (
                <span className="px-3 py-1 bg-cyan-100 text-cyan-700 rounded-full text-sm font-medium">
                  {selectedCategory}
                </span>
              )}
              {selectedPriceRange !== null && (
                <span className="px-3 py-1 bg-cyan-100 text-cyan-700 rounded-full text-sm font-medium">
                  {priceRanges[selectedPriceRange].label}
                </span>
              )}
              {inStockOnly && (
                <span className="px-3 py-1 bg-cyan-100 text-cyan-700 rounded-full text-sm font-medium">
                  In Stock
                </span>
              )}
              <button
                onClick={clearFilters}
                className="text-sm text-cyan-600 hover:text-cyan-700 font-medium"
              >
                Clear all
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Filters Sidebar */}
      <div
        className={`fixed right-0 top-[129px] md:top-[113px] bottom-0 w-80 bg-white shadow-xl z-50 transform transition-transform duration-300 overflow-y-auto ${
          showFilters ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-lg text-[#0a1628]">Filters</h3>
            <button
              onClick={() => setShowFilters(false)}
              className="text-gray-500 hover:text-gray-700"
            >
              ✕
            </button>
          </div>

          {/* Category Filter */}
          <div>
            <h4 className="font-medium text-[#0a1628] mb-3">Category</h4>
            <div className="space-y-2">
              {categories.map((cat) => (
                <label key={cat} className="flex items-center gap-2 cursor-pointer group">
                  <input
                    type="radio"
                    checked={selectedCategory === cat}
                    onChange={() => setSelectedCategory(cat)}
                    className="w-4 h-4 text-cyan-500 focus:ring-cyan-400"
                  />
                  <span className="text-sm text-gray-700 group-hover:text-cyan-600 transition-colors capitalize">
                    {cat}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <h4 className="font-medium text-[#0a1628] mb-3">Price Range</h4>
            <div className="space-y-2">
              {priceRanges.map((range, index) => (
                <label key={index} className="flex items-center gap-2 cursor-pointer group">
                  <input
                    type="radio"
                    checked={selectedPriceRange === index}
                    onChange={() => setSelectedPriceRange(selectedPriceRange === index ? null : index)}
                    className="w-4 h-4 text-cyan-500 focus:ring-cyan-400"
                  />
                  <span className="text-sm text-gray-700 group-hover:text-cyan-600 transition-colors">
                    {range.label}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Usage Type */}
          <div>
            <h4 className="font-medium text-[#0a1628] mb-3">Usage</h4>
            <div className="space-y-2">
              {usageTypes.map((usage) => (
                <label key={usage} className="flex items-center gap-2 cursor-pointer group">
                  <input
                    type="checkbox"
                    checked={selectedUsage.includes(usage)}
                    onChange={() => toggleUsage(usage)}
                    className="w-4 h-4 text-cyan-500 focus:ring-cyan-400 rounded"
                  />
                  <span className="text-sm text-gray-700 group-hover:text-cyan-600 transition-colors">
                    {usage}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Power Rating */}
          <div>
            <h4 className="font-medium text-[#0a1628] mb-3">Power Rating</h4>
            <div className="space-y-2">
              {powerRatings.map((power) => (
                <label key={power} className="flex items-center gap-2 cursor-pointer group">
                  <input
                    type="checkbox"
                    checked={selectedPower.includes(power)}
                    onChange={() => togglePower(power)}
                    className="w-4 h-4 text-cyan-500 focus:ring-cyan-400 rounded"
                  />
                  <span className="text-sm text-gray-700 group-hover:text-cyan-600 transition-colors">
                    {power}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Availability */}
          <div>
            <h4 className="font-medium text-[#0a1628] mb-3">Availability</h4>
            <label className="flex items-center gap-2 cursor-pointer group">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => setInStockOnly(e.target.checked)}
                className="w-4 h-4 text-cyan-500 focus:ring-cyan-400 rounded"
              />
              <span className="text-sm text-gray-700 group-hover:text-cyan-600 transition-colors">
                In Stock Only
              </span>
            </label>
          </div>
        </div>
      </div>

      {/* Overlay */}
      {showFilters && (
        <div
          onClick={() => setShowFilters(false)}
          className="fixed inset-0 bg-black/50 z-40"
        />
      )}

      {/* Products Grid */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <p className="text-sm text-gray-600 mb-4">
          Showing {filteredProducts.length} products
        </p>

        <div className={`grid gap-6 ${
          viewMode === 'grid'
            ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'
            : 'grid-cols-1'
        }`}>
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onWishlistToggle={onWishlistToggle}
              isInWishlist={wishlist.includes(product.id)}
            />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No products found</p>
            <button
              onClick={clearFilters}
              className="mt-4 text-cyan-600 hover:text-cyan-700 font-medium"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
