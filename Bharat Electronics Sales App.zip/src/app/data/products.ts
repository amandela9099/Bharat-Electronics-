import { Product } from '../components/ProductCard';

export const products: Product[] = [
  // Fans
  { id: 'f1', name: 'Bharat Ceiling Fan 1200mm High Speed', price: 2499, image: 'https://images.unsplash.com/photo-1612954357971-cb8fa0b92b6a?w=400', category: 'Fan', rating: 4.5, inStock: true },
  { id: 'f2', name: 'Premium Table Fan with Remote Control', price: 1899, image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400', category: 'Fan', rating: 4.3, inStock: true },
  { id: 'f3', name: 'Energy Efficient Pedestal Fan', price: 2199, image: 'https://images.unsplash.com/photo-1612954357971-cb8fa0b92b6a?w=400', category: 'Fan', rating: 4.6, inStock: true },
  
  // Lamps
  { id: 'l1', name: 'LED Desk Lamp with Touch Control', price: 899, image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400', category: 'Lamp', rating: 4.4, inStock: true },
  { id: 'l2', name: 'Smart LED Bulb Color Changing', price: 599, image: 'https://images.unsplash.com/photo-1550985616-10810253b84d?w=400', category: 'Lamp', rating: 4.2, inStock: true },
  { id: 'l3', name: 'Designer Floor Lamp Modern', price: 3499, image: 'https://images.unsplash.com/photo-1524484485831-a92ffc0de03f?w=400', category: 'Lamp', rating: 4.7, inStock: true },
  
  // Geyser
  { id: 'g1', name: 'Instant Water Heater 3L Geyser', price: 4999, image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=400', category: 'Geyser', rating: 4.5, inStock: true },
  { id: 'g2', name: 'Storage Water Heater 15L', price: 7999, image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=400', category: 'Geyser', rating: 4.6, inStock: true },
  
  // Sandwich Maker
  { id: 's1', name: 'Grill Sandwich Maker 4 Slice', price: 1299, image: 'https://images.unsplash.com/photo-1600289031464-74d374b64991?w=400', category: 'Sandwich Maker', rating: 4.3, inStock: true },
  { id: 's2', name: 'Multi-Function Sandwich Toaster', price: 1799, image: 'https://images.unsplash.com/photo-1600289031464-74d374b64991?w=400', category: 'Sandwich Maker', rating: 4.4, inStock: true },
  
  // Mixer
  { id: 'm1', name: '750W Mixer Grinder with 3 Jars', price: 3299, image: 'https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=400', category: 'Mixer', rating: 4.6, inStock: true },
  { id: 'm2', name: 'Heavy Duty Mixer Grinder 1000W', price: 4999, image: 'https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=400', category: 'Mixer', rating: 4.7, inStock: true },
  
  // LED TV
  { id: 't1', name: '32" HD Ready Smart LED TV', price: 12999, image: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400', category: 'LED TV', rating: 4.5, inStock: true },
  { id: 't2', name: '43" Full HD Android TV', price: 21999, image: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400', category: 'LED TV', rating: 4.7, inStock: true },
  { id: 't3', name: '55" 4K Ultra HD Smart TV', price: 34999, image: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400', category: 'LED TV', rating: 4.8, inStock: true },
  
  // Tap
  { id: 'ta1', name: 'Premium Brass Kitchen Tap', price: 899, image: 'https://images.unsplash.com/photo-1585121858959-2e3f0dcd1e5f?w=400', category: 'Tap', rating: 4.4, inStock: true },
  { id: 'ta2', name: 'Sensor Automatic Water Tap', price: 2499, image: 'https://images.unsplash.com/photo-1585121858959-2e3f0dcd1e5f?w=400', category: 'Tap', rating: 4.6, inStock: true },
  
  // Home Theater
  { id: 'ht1', name: '5.1 Home Theater System 1000W', price: 18999, image: 'https://images.unsplash.com/photo-1545127398-14699f92334b?w=400', category: 'Home Theater', rating: 4.6, inStock: true },
  { id: 'ht2', name: 'Soundbar with Subwoofer', price: 9999, image: 'https://images.unsplash.com/photo-1545127398-14699f92334b?w=400', category: 'Home Theater', rating: 4.5, inStock: true },
  
  // LED Light
  { id: 'led1', name: '9W LED Bulb Pack of 4', price: 399, image: 'https://images.unsplash.com/photo-1550985616-10810253b84d?w=400', category: 'LED Light', rating: 4.3, inStock: true },
  { id: 'led2', name: 'Smart WiFi LED Strip Light 5m', price: 1299, image: 'https://images.unsplash.com/photo-1550985616-10810253b84d?w=400', category: 'LED Light', rating: 4.5, inStock: true },
  
  // Wiring
  { id: 'w1', name: 'Electrical Wire 90m Roll 1.5mm', price: 1599, image: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=400', category: 'Wiring', rating: 4.6, inStock: true },
  { id: 'w2', name: 'Multi-Strand Copper Wire 2.5mm', price: 2799, image: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=400', category: 'Wiring', rating: 4.7, inStock: true },
  
  // Switch
  { id: 'sw1', name: 'Modular Switch 6A White (Pack of 5)', price: 499, image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400', category: 'Switch', rating: 4.4, inStock: true },
  { id: 'sw2', name: 'Touch Screen Smart Switch', price: 1299, image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400', category: 'Switch', rating: 4.5, inStock: true },
  
  // Regulator
  { id: 'r1', name: 'Fan Regulator 5 Step Control', price: 199, image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400', category: 'Regulator', rating: 4.3, inStock: true },
  { id: 'r2', name: 'Digital Fan Regulator with Display', price: 599, image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400', category: 'Regulator', rating: 4.5, inStock: true },
];

export const categories = [
  { id: 'fan', name: 'Fan', icon: '🌀' },
  { id: 'lamp', name: 'Lamp', icon: '💡' },
  { id: 'geyser', name: 'Geyser', icon: '♨️' },
  { id: 'sandwich-maker', name: 'Sandwich Maker', icon: '🍞' },
  { id: 'mixer', name: 'Mixer', icon: '🔄' },
  { id: 'led-tv', name: 'LED TV', icon: '📺' },
  { id: 'tap', name: 'Tap', icon: '🚰' },
  { id: 'home-theater', name: 'Home Theater', icon: '🔊' },
  { id: 'led-light', name: 'LED Light', icon: '💡' },
  { id: 'wiring', name: 'Wiring', icon: '⚡' },
  { id: 'switch', name: 'Switch', icon: '🔘' },
  { id: 'regulator', name: 'Regulator', icon: '🎛️' },
];
