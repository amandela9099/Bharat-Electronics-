import { useState } from 'react';
import { AppBar } from './components/AppBar';
import { BottomNav } from './components/BottomNav';
import { HomePage } from './pages/HomePage';
import { CategoryPage } from './pages/CategoryPage';
import { WishlistPage } from './pages/WishlistPage';
import { CartPage } from './pages/CartPage';
import { ProfilePage } from './pages/ProfilePage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';

type Page = 'home' | 'category' | 'wishlist' | 'cart' | 'profile' | 'login' | 'signup';

interface CartItem {
  productId: string;
  quantity: number;
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('login');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);

  const handleLogin = () => {
    setIsAuthenticated(true);
    setCurrentPage('home');
  };

  const handleSignup = () => {
    setIsAuthenticated(true);
    setCurrentPage('home');
  };

  const handleWishlistToggle = (productId: string) => {
    setWishlist(prev =>
      prev.includes(productId)
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const handleAddToCart = (productId: string) => {
    setCart(prev => {
      const existingItem = prev.find(item => item.productId === productId);
      if (existingItem) {
        return prev.map(item =>
          item.productId === productId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { productId, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity === 0) {
      setCart(prev => prev.filter(item => item.productId !== productId));
    } else {
      setCart(prev =>
        prev.map(item =>
          item.productId === productId ? { ...item, quantity } : item
        )
      );
    }
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.productId !== productId));
  };

  const handleNavigate = (page: Page) => {
    setCurrentPage(page);
    window.scrollTo(0, 0);
  };

  // Show login/signup pages if not authenticated
  if (!isAuthenticated) {
    if (currentPage === 'signup') {
      return (
        <SignupPage
          onSwitchToLogin={() => setCurrentPage('login')}
          onSignup={handleSignup}
        />
      );
    }
    return (
      <LoginPage
        onSwitchToSignup={() => setCurrentPage('signup')}
        onLogin={handleLogin}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AppBar cartItemCount={cart.length} />

      {/* Page Content */}
      {currentPage === 'home' && (
        <HomePage
          onWishlistToggle={handleWishlistToggle}
          wishlist={wishlist}
        />
      )}

      {currentPage === 'category' && (
        <CategoryPage
          onWishlistToggle={handleWishlistToggle}
          wishlist={wishlist}
        />
      )}

      {currentPage === 'wishlist' && (
        <WishlistPage
          wishlist={wishlist}
          onWishlistToggle={handleWishlistToggle}
          onAddToCart={handleAddToCart}
        />
      )}

      {currentPage === 'cart' && (
        <CartPage
          cart={cart}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveFromCart}
        />
      )}

      {currentPage === 'profile' && <ProfilePage />}

      <BottomNav
        currentPage={currentPage}
        onNavigate={(page) => handleNavigate(page as Page)}
        cartCount={cart.length}
        wishlistCount={wishlist.length}
      />
    </div>
  );
}
